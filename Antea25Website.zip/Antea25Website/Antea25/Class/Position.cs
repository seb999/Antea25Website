 internal class Position
 {
    //The device that will be use to identify the
    public int Latitude { get; set; }
    public int Longitude { get; set; }
    public int LatitudeDecimal { get; set; }
    public int LongitudeDecimal { get; set; }
}