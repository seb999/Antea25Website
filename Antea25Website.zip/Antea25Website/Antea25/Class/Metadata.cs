using System;

internal class Metadata
 {
    //The device that will be use to identify the
    public DateTime Time { get; set; }

}